package Properties;

public class Sample_Properties{
	
}